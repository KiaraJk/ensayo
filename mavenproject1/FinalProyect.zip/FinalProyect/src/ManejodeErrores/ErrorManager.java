package manejodeerrores;

import modelo.Errores;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;

public class ErrorManager {
    private static final String RUTA_LOG = "E:\\ProyectoProgramacion\\FinalProyect\\FinalProyect\\errores.log"; // Cambia la ruta según sea necesario

    public static void guardarError(Errores error) {
        // Crear el archivo si no existe
        File archivo = new File(RUTA_LOG);
        try {
            if (archivo.createNewFile()) {
                System.out.println("Archivo de errores creado: " + archivo.getName());
            }
        } catch (IOException e) {
            System.err.println("No se pudo crear el archivo de errores: " + e.getMessage());
        }

        // Escribir el error en el archivo
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(RUTA_LOG, true))) {
            writer.write(error.toString());
            writer.newLine();
        } catch (IOException e) {
            System.err.println("No se pudo guardar el error: " + e.getMessage());
        }
    }
}
