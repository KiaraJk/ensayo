package vista;

import modelo.Carnet; // Clase Carnet del paquete modelo
import manejodeerrores.ErrorManager;

import javax.swing.*; // Componentes GUI Swing
import java.awt.*; // Clases para interfaz de usuario y gráficos
import java.io.FileWriter; // Escritura de archivos de caracteres
import java.io.IOException; // Excepciones de entrada/salida
import java.util.List; // Colecciones ordenadas de objetos
import java.util.Map; // Estructuras de mapa clave-valor
import java.util.stream.Collectors; // Operaciones de streams y colectores
import modelo.Errores;

public class CarnetView {
    
    private JFrame frame; // Frame principal de la interfaz gráfica
    private JComboBox<String> comboReportes; // ComboBox para seleccionar tipo de reporte
    private JComboBox<String> comboUniversidades; // ComboBox para seleccionar universidades
    private JComboBox<String> comboTipoGestion; // ComboBox para seleccionar tipo de gestión
    private JComboBox<String> comboFilial; // ComboBox para seleccionar filiales
    private JComboBox<String>comboProgramasEstudio; //ComboBox para seleccionar programa de estudio
    private JButton btnGenerarReporte; // Botón para generar reportes
    private List<Carnet> carnets; // Lista de carnets cargados desde datos
 
public CarnetView() {
    initialize(); // Llama al método para inicializar la interfaz gráfica y otros componentes
}
   
private void initialize() {
    // Configuración del frame principal
    frame = new JFrame();
    frame.setBounds(100, 100, 800, 500);  // Establece las dimensiones y posición del JFrame
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  // Cierra la aplicación al cerrar la ventana
    frame.getContentPane().setLayout(null);  // Configura el layout del contenedor principal como nulo (para posicionamiento absoluto)
    
    // ComboBox para seleccionar el tipo de reporte
    comboReportes = new JComboBox<>();
    comboReportes.setBounds(30, 30, 300, 30);  // Posición y tamaño del ComboBox
    comboReportes.addItem("Seleccione un tipo de reporte");  // Añade ítem inicial
    comboReportes.addItem("Reporte por Universidad"); //Opciones
    comboReportes.addItem("Reporte por Tipo de Gestión");
    comboReportes.addItem("Análisis por Departamento o Filial");
    comboReportes.addItem("Reporte de Programas de Estudio");
    comboReportes.addActionListener(e -> actualizarOpciones());  // ActionListener para actualizar opciones al seleccionar un reporte
    frame.getContentPane().add(comboReportes);  // Agrega el ComboBox al contenedor del frame
    
    // ComboBox para seleccionar universidades
    comboUniversidades = new JComboBox<>();
    comboUniversidades.setBounds(30, 80, 450, 30);  // Posición y tamaño
    comboUniversidades.setEnabled(false);  // Inicialmente deshabilitado
    frame.getContentPane().add(comboUniversidades);  // Agrega el ComboBox al contenedor del frame
    
    // ComboBox para seleccionar tipo de gestión
    comboTipoGestion = new JComboBox<>();
    comboTipoGestion.setBounds(30, 130, 300, 30);  // Posición y tamaño
    comboTipoGestion.addItem("Todas"); //Opciones
    comboTipoGestion.addItem("PUBLICO");
    comboTipoGestion.addItem("PRIVADO");
    comboTipoGestion.setEnabled(false);  // Inicialmente deshabilitado
    frame.getContentPane().add(comboTipoGestion);  // Agrega el ComboBox al contenedor del frame
    
    // ComboBox para seleccionar filial
    comboFilial = new JComboBox<>();
    comboFilial.setBounds(30, 180, 300, 30);  // Posición y tamaño
    comboFilial.setEnabled(false);  // Inicialmente deshabilitado
    frame.getContentPane().add(comboFilial);  // Agrega el ComboBox al contenedor del frame

    // ComboBox para seleccionar programas de estudios
    comboProgramasEstudio = new JComboBox<>();
    comboProgramasEstudio.setBounds(30, 230, 300, 30);  // Posición y tamaño
    comboProgramasEstudio.setEnabled(false);  // Inicialmente deshabilitado
    frame.getContentPane().add(comboProgramasEstudio);  // Agrega el ComboBox al contenedor del frame

    // Botón para generar reporte
    btnGenerarReporte = new JButton("Generar Reporte");
    btnGenerarReporte.setBounds(500, 300, 150, 30);  // Posición y tamaño del botón
    btnGenerarReporte.addActionListener(e -> {
        String reporte = generarReporteSeleccionado();  // Genera el reporte seleccionado
        mostrarReporte(reporte);  // Muestra el reporte generado en la interfaz
    });
    frame.getContentPane().add(btnGenerarReporte);  // Agrega el botón al contenedor del frame   
}

public void mostrarVentana() {
    frame.setVisible(true);  // Hace visible la ventana principal
 }

public void setCarnets(List<Carnet> carnets) {
    this.carnets = carnets;

    // Agregar opciones al combo de universidades
    List<String> nombresUniversidad = carnets.stream()
        .map(Carnet::getUniversidad)
        .distinct()
        .collect(Collectors.toList());

    agregarOpcionesNombresUniversidad(nombresUniversidad);

    // Habilitar las filiales y cargar programas según la universidad seleccionada
comboUniversidades.addActionListener(e -> {
    String universidadSeleccionada = (String) comboUniversidades.getSelectedItem();
    if (!"Todas las universidades".equals(universidadSeleccionada)) {
        List<String> nombresFilial = carnets.stream()
            .filter(c -> c.getUniversidad().equals(universidadSeleccionada))
            .map(Carnet::getDepartamentoFilial)
            .distinct()
            .collect(Collectors.toList());
        agregarOpcionesFilial(nombresFilial);
        comboFilial.setEnabled(true);
        // Cargar programas de estudio para la universidad seleccionada
        cargarProgramasEstudio(universidadSeleccionada);
    } else {
        comboFilial.removeAllItems();
        comboFilial.setEnabled(false);
        comboProgramasEstudio.removeAllItems();
        comboProgramasEstudio.setEnabled(false);
    }
});
}

public void cargarProgramasEstudio(String universidadSeleccionada) {
    List<String> nombresProgramasEstudio = carnets.stream()
        .filter(c -> c.getUniversidad().equals(universidadSeleccionada))
        .map(Carnet::getNombrePrograma)
        .distinct()
        .collect(Collectors.toList());
    agregarOpcionesProgramasEstudio(nombresProgramasEstudio);
    comboProgramasEstudio.setEnabled(true);
}

// Método para agregar opciones al combo box de programas de estudio
public void agregarOpcionesProgramasEstudio(List<String> nombresProgramasEstudio) {
    comboProgramasEstudio.removeAllItems();
    comboProgramasEstudio.addItem("Seleccione un programa de estudio");
    for (String nombre : nombresProgramasEstudio) {
        comboProgramasEstudio.addItem(nombre);
    }
}
public void cargarFiliales(String universidadSeleccionada) {
    List<String> nombresFiliales = carnets.stream()
        .filter(c -> c.getUniversidad().equals(universidadSeleccionada))
        .map(Carnet::getDepartamentoFilial)
        .distinct()
        .collect(Collectors.toList());

    if (!nombresFiliales.isEmpty()) {
        agregarOpcionesFilial(nombresFiliales);
        comboFilial.setEnabled(true); // Habilitar ComboBox de filiales
    } else {
        comboFilial.setEnabled(false); // Deshabilitar si no hay filiales
    }
}


// Método para agregar opciones al combo box de filiales
public void agregarOpcionesFilial(List<String> nombresFilial) {
    comboFilial.removeAllItems();
    comboFilial.addItem("Seleccione una filial");
    for (String nombre : nombresFilial) {
        comboFilial.addItem(nombre);
    }
}


// Método para agregar opciones al combo box de universidades
public void agregarOpcionesNombresUniversidad(List<String> nombresUniversidad) {
    comboUniversidades.removeAllItems(); // Remueve todos los elementos del combo de universidades
    comboUniversidades.addItem("Todas las universidades"); // Agrega la opción "Todas las universidades"
    for (String nombre : nombresUniversidad) {
        comboUniversidades.addItem(nombre); // Agrega cada nombre de universidad al combo
    }
}


private List<Carnet> filtrarPorTipoGestion(String tipoGestionSeleccionada) {
    if ("Todas".equals(tipoGestionSeleccionada)) {
        return carnets;
    } else {
        return carnets.stream()
                .filter(c -> c.getTipoGestion().equals(tipoGestionSeleccionada))
                .collect(Collectors.toList());
    }
}  
    
private int contarCarnetsPorTipoGestion(String tipoGestion) {
    return (int) carnets.stream()
            .filter(c -> c.getTipoGestion().equals(tipoGestion))
            .count();  
}

private void actualizarOpciones() {
    String tipoReporte = (String) comboReportes.getSelectedItem();

    switch (tipoReporte) {
        case "Reporte por Universidad":
            comboUniversidades.setEnabled(true);
            comboTipoGestion.setEnabled(false);
            comboFilial.setEnabled(false);
            comboProgramasEstudio.setEnabled(false);
            break;

        case "Reporte por Tipo de Gestión":
            comboUniversidades.setEnabled(false);
            comboTipoGestion.setEnabled(true);
            comboFilial.setEnabled(false);
            comboProgramasEstudio.setEnabled(false);
            break;

        case "Análisis por Departamento o Filial":
            comboUniversidades.setEnabled(true);
            comboTipoGestion.setEnabled(false);
            comboFilial.setEnabled(true);
            comboProgramasEstudio.setEnabled(false);
            break;

        case "Reporte de Programas de Estudio":
            comboUniversidades.setEnabled(true);
            comboTipoGestion.setEnabled(false);
            comboFilial.setEnabled(false);
            comboProgramasEstudio.setEnabled(true);
            break;

        default:
            comboUniversidades.setEnabled(false);
            comboTipoGestion.setEnabled(false);
            comboFilial.setEnabled(false);
            comboProgramasEstudio.setEnabled(false);
            break;
    }
}

  
private String generarReporteSeleccionado() {
    String tipoReporte = (String) comboReportes.getSelectedItem(); // Obtiene el tipo de reporte seleccionado

    try {
        switch (tipoReporte) {
            case "Reporte por Universidad" -> {
                String universidadSeleccionada = (String) comboUniversidades.getSelectedItem();
                String tipoGestionSeleccionadaUni = (String) comboTipoGestion.getSelectedItem();
                return generarReportePorUniversidad(universidadSeleccionada, tipoGestionSeleccionadaUni);
            }

            case "Reporte por Tipo de Gestión" -> {
                String gestionSeleccionada = (String) comboTipoGestion.getSelectedItem();
                return generarReportePorTipoGestion(gestionSeleccionada);
            }

            case "Análisis por Departamento o Filial" -> {
                return generarReportePorDepartamentoFilial();
            }

            case "Reporte de Programas de Estudio" -> {
                return generarReportePorProgramaEstudio();
            }

            default -> {
                throw new IllegalArgumentException("Seleccione un tipo de reporte válido."); // Lanzar excepción
            }
        }
    } catch (IllegalArgumentException e) {
        ErrorManager.guardarError(new Errores(e.getMessage(), "Argumento Inválido", "Sistema")); // Registrar error
        return e.getMessage(); // Mensaje de error
    } catch (Exception e) {
        ErrorManager.guardarError(new Errores("Error al generar el reporte: " + e.getMessage(), "Excepción General", "Sistema")); // Registrar error
        return "Error al generar el reporte: " + e.getMessage(); // Mensaje para otros errores
    }
}

  
 private String generarReportePorUniversidad(String universidadSeleccionada, String tipoGestionSeleccionada) {
    System.out.println("Generando reporte por universidad para: " + universidadSeleccionada + " - Tipo de gestión: " + tipoGestionSeleccionada); // Mensaje de depuración

    // Deshabilitar los JComboBoxes de filial y programa de estudio al seleccionar una universidad
    if (!"Todas las universidades".equals(universidadSeleccionada)) {
        comboFilial.setEnabled(false);
        comboProgramasEstudio.setEnabled(false);
    }

    List<Carnet> carnetsFiltrados;
    if ("Todas las universidades".equals(universidadSeleccionada)) {
        carnetsFiltrados = filtrarPorTipoGestion(tipoGestionSeleccionada);
    } else {
        carnetsFiltrados = carnets.stream()
                .filter(c -> c.getUniversidad().equals(universidadSeleccionada) &&
                        (tipoGestionSeleccionada.equals("Todas") || c.getTipoGestion().equals(tipoGestionSeleccionada)))
                .collect(Collectors.toList());
    }

    // Genera un mapa agrupando por universidad y sumando la cantidad de carnés por universidad
    Map<String, Long> reporte = carnetsFiltrados.stream()
            .collect(Collectors.groupingBy(Carnet::getUniversidad,
                                           Collectors.summingLong(Carnet::getCantCarnes)));

    // Construye el reporte en formato de texto
    StringBuilder sb = new StringBuilder();
    sb.append("\n##############################################################\n");
    sb.append("\nReporte de Distribución de Carnés por Universidad \n");

    int[] anios = {2018};
    for (int anio : anios) {
        sb.append("En base a los datos del año ").append(anio).append("\n");
    }

    sb.append("\n##############################################################\n");

    reporte.forEach((uni, cantidad) -> {
        sb.append("\nUNIVERSIDAD: ").append(uni).append("\n");
        sb.append("CANTIDAD DE CARNÉS: ").append(cantidad).append("\n");
    });

    sb.append("\n##############################################################\n");

    return sb.toString(); // Devuelve el reporte generado como String
}
  
private String generarReportePorTipoGestion(String gestionSeleccionada) {
    System.out.println("Generando reporte por tipo de gestión para: " + gestionSeleccionada); // Mensaje de depuración

    // Filtra los carnets por el tipo de gestión seleccionado
    List<Carnet> carnetsFiltrados = filtrarPorTipoGestion(gestionSeleccionada);

    // Cuenta la cantidad total de carnés públicos y privados
    int totalPublicos = contarCarnetsPorTipoGestion("PUBLICO");
    int totalPrivados = contarCarnetsPorTipoGestion("PRIVADO");

    // Construye el encabezado y los totales de carnés por tipo de gestión
    StringBuilder sb = new StringBuilder();
    sb.append("\n##############################################################\n");
    sb.append("Tipo de Gestión      Cantidad de Carnés\n");
    // Añadir años al reporte usando un arreglo
    int[] anios = {2018};
    for (int anio : anios) {
        sb.append("En base a los datos del año ").append(anio).append("\n");
    }
    sb.append("--------------------------------------------------------------\n");
    sb.append(String.format("PRIVADO              : %d carnés\n", totalPrivados));
    sb.append(String.format("PUBLICO              : %d carnés\n", totalPublicos));
    sb.append("\n##############################################################\n\n");

    // Agrupa los carnets filtrados por universidad y luego por tipo de gestión
    Map<String, Map<String, Long>> reporte = carnetsFiltrados.stream()
            .collect(Collectors.groupingBy(Carnet::getUniversidad,
                    Collectors.groupingBy(Carnet::getTipoGestion, Collectors.counting())));

    // Detalla la cantidad de carnés por cada universidad y tipo de gestión
    reporte.forEach((universidad, tiposGestion) -> {
        sb.append(String.format("\nUniversidad: %s\n", universidad));
        tiposGestion.forEach((tipoGestion, cantidad) -> {
            sb.append(String.format("\n- Tipo de Gestión: %s, Cantidad de Carnés: %d\n", tipoGestion, cantidad));
        });
        // Calcula el total de carnés por tipo de gestión para esa universidad
        long total = tiposGestion.values().stream().mapToLong(Long::longValue).sum();
        sb.append(String.format("- Total: %d carnés\n\n", total));
    });

    sb.append("\n##############################################################\n");
    return sb.toString(); // Devuelve el reporte generado como String
}

private String generarReportePorDepartamentoFilial() {
    // Obtiene la universidad seleccionada y la filial seleccionada
    String universidadSeleccionada = (String) comboUniversidades.getSelectedItem();
    String filialSeleccionada = (String) comboFilial.getSelectedItem();

    // Filtra los carnets por universidad y filial seleccionadas
    List<Carnet> carnetsFiltrados = carnets.stream()
        .filter(c -> (universidadSeleccionada.equals("Todas las universidades") || c.getUniversidad().equals(universidadSeleccionada)) &&
                (filialSeleccionada == null || filialSeleccionada.isEmpty() || filialSeleccionada.equals("Seleccione una filial") || c.getDepartamentoFilial().equals(filialSeleccionada)))
        .collect(Collectors.toList());

    // Agrupa los carnets filtrados por universidad y filial, y suma la cantidad de carnés
    Map<String, Map<String, Long>> reporte = carnetsFiltrados.stream()
        .collect(Collectors.groupingBy(
            Carnet::getUniversidad,
            Collectors.groupingBy(
                Carnet::getDepartamentoFilial,
                Collectors.summingLong(Carnet::getCantCarnes)
            )
        ));

    // Construye el reporte en formato de texto
    StringBuilder sb = new StringBuilder();
    sb.append("\n##############################################################\n");
    sb.append("\nReporte de Distribución de Carnés por Departamento o Filial\n");

    // Añadir años al reporte usando un arreglo
    int[] anios = {2018};
    for (int anio : anios) {
        sb.append("En base a los datos del año ").append(anio).append("\n");
    }

    sb.append("\n##############################################################\n");

        // Verifica si hay carnets filtrados
        if (reporte.isEmpty()) {
            Errores error = new Errores("No se encontraron carnés para los criterios seleccionados.", "No Resultados", "Sistema"); // Crear objeto Errores
            ErrorManager.guardarError(error); // Registrar el error
            sb.append(error.toString()); // Añadir el mensaje de error al StringBuilder
        } else {
            // Itera sobre el mapa de reporte por universidad y construye cada línea del reporte
            reporte.forEach((universidad, mapFilialCarnets) -> {
                sb.append("\nUNIVERSIDAD: ").append(universidad).append("\n");
                mapFilialCarnets.forEach((filial, cantidad) -> {
                    sb.append(filial).append(": ").append(cantidad).append("\n");
                });
            });
        }

    sb.append("\n##############################################################\n");

    return sb.toString(); // Devuelve el reporte generado como String
}



private String generarReportePorProgramaEstudio() {
    System.out.println("Generando reporte por programa de estudio");

    final String programaEstudioSeleccionado = (String) comboProgramasEstudio.getSelectedItem();
    final String universidadSeleccionada = (String) comboUniversidades.getSelectedItem();

    // Establece valores por defecto
    String programaEstudio = programaEstudioSeleccionado != null ? programaEstudioSeleccionado : "Seleccione un programa de estudio";
    String universidad = universidadSeleccionada != null ? universidadSeleccionada : "Todas las universidades";

    List<Carnet> carnetsFiltrados = carnets.stream()
        .filter(c -> (universidad.equals("Todas las universidades") || 
                       c.getUniversidad().equals(universidad)) &&
                     (programaEstudio.equals("Seleccione un programa de estudio") || 
                       c.getNombrePrograma().equals(programaEstudio)))
        .collect(Collectors.toList());

    if (carnetsFiltrados.isEmpty()) {
        return "No se encontraron carnés para los criterios seleccionados: " 
               + "Programa: " + programaEstudio + ", " 
               + "Universidad: " + universidad;
    }

    Map<String, Map<String, Long>> reporte = carnetsFiltrados.stream()
        .collect(Collectors.groupingBy(Carnet::getUniversidad,
                Collectors.groupingBy(Carnet::getNombrePrograma,
                        Collectors.summingLong(Carnet::getCantCarnes))));

    // Construcción del reporte
    StringBuilder sb = new StringBuilder();
    sb.append("\n##############################################################\n");
    sb.append("\nReporte de Distribución de Carnés por Programa de Estudio\n");
    int[] anios = {2018};
    for (int anio : anios) {
        sb.append("En base a los datos del año ").append(anio).append("\n");
    }
    sb.append("\n##############################################################\n\n");

    for (Map.Entry<String, Map<String, Long>> universidadEntry : reporte.entrySet()) {
        String universidadActual = universidadEntry.getKey();
        sb.append(universidadActual).append("\n\n");

        Map<String, Long> programas = universidadEntry.getValue();
        for (Map.Entry<String, Long> programaEntry : programas.entrySet()) {
            String programaEstudioActual = programaEntry.getKey();
            sb.append(programaEstudioActual).append("\n");
            sb.append("Cantidad de Carnes: ").append(programaEntry.getValue()).append("\n\n");
        }

        sb.append("\n");
    }

    sb.append("##############################################################\n");

    return sb.toString();
}


    
    
private void mostrarReporte(String reporte) {
    // Crear un JTextArea para mostrar el reporte
    JTextArea textArea = new JTextArea(reporte);
    textArea.setEditable(false); // El texto no es editable por el usuario

    // Crear un JScrollPane y agregar el JTextArea a él
    JScrollPane scrollPane = new JScrollPane(textArea);
    scrollPane.setPreferredSize(new Dimension(600, 400)); // Establecer tamaño preferido del JScrollPane

    // Crear un JFrame para mostrar el reporte
    JFrame reportFrame = new JFrame("Reporte Generado");
    reportFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Cerrar solo la ventana al salir
    reportFrame.getContentPane().add(scrollPane); // Agregar el JScrollPane al JFrame
    reportFrame.pack(); // Ajustar tamaño del JFrame automáticamente
    reportFrame.setVisible(true); // Hacer visible el JFrame

    // Guardar el reporte en un archivo de texto
    try {
        FileWriter writer = new FileWriter("reporte.txt"); // Crear un FileWriter para el archivo 'reporte.txt'
        writer.write(reporte); // Escribir el reporte en el archivo
        writer.close(); // Cerrar el FileWriter después de escribir
        // Mostrar mensaje de confirmación de guardado
        JOptionPane.showMessageDialog(reportFrame, "El reporte ha sido guardado en 'reporte.txt'.");
    } catch (IOException e) {
        // Mostrar mensaje de error si ocurre una excepción al guardar
        JOptionPane.showMessageDialog(reportFrame, "Error al guardar el reporte: " + e.getMessage());
    }
}

    // Método para mostrar mensajes en un cuadro de diálogo
public void mostrarMensaje(String mensaje) {
    JOptionPane.showMessageDialog(frame, mensaje); // Mostrar el mensaje utilizando JOptionPane
}
}