package controlador;

import modelo.Carnet;
import modelo.Errores;
import vista.CarnetView;
import manejodeerrores.ErrorManager;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class CarnetController {
    private static final String ARCHIVO_CARNETS = "E:\\ProyectoProgramacion\\Carnes Universitarios 2018.txt";
    private CarnetView view;

    public CarnetController(CarnetView view) {
        this.view = view;
    }

    public void iniciar() {
        try {
            List<Carnet> carnets = cargarDatosDesdeArchivo(ARCHIVO_CARNETS);
            view.setCarnets(carnets);
            view.mostrarMensaje("Datos cargados correctamente desde el archivo:\n \n" + ARCHIVO_CARNETS +"\n\n");
            agregarOpcionesNombresUniversidad(carnets);
        } catch (IOException e) {
            Errores error = new Errores("Error al cargar los datos desde el archivo: " + e.getMessage(), "IOException", "Sistema");
            ErrorManager.guardarError(error);
            view.mostrarMensaje(error.toString());
        }
    }

    private List<Carnet> cargarDatosDesdeArchivo(String filePath) throws IOException {
        List<String> lineas = Files.readAllLines(Paths.get(filePath));
        List<Carnet> carnets = new ArrayList<>();

        for (String linea : lineas) {
            String[] partes = linea.split(";");
            if (partes.length == 10) {
                try {
                    Carnet carnet = crearCarnetDesdePartes(partes);
                    carnets.add(carnet);
                } catch (NumberFormatException e) {
                    Errores error = new Errores("Número inválido en la línea: " + linea, "NumberFormatException", "Sistema");
                    ErrorManager.guardarError(error);
                }
            } else {
                Errores error = new Errores("Línea inválida (saltada): " + linea, "FormatoIncorrecto", "Sistema");
                ErrorManager.guardarError(error);
            }
        }

        System.out.println("Total de datos cargados: " + carnets.size());
        return carnets;
    }

    private Carnet crearCarnetDesdePartes(String[] partes) {
        return new Carnet(partes[0], partes[1], partes[2], partes[3], partes[4],
                partes[5], partes[6], partes[7], partes[8], Integer.parseInt(partes[9]));
    }

    private void agregarOpcionesNombresUniversidad(List<Carnet> carnets) {
        List<String> nombresUniversidad = carnets.stream()
                .map(Carnet::getUniversidad)
                .distinct()
                .collect(Collectors.toList());
        view.agregarOpcionesNombresUniversidad(nombresUniversidad);
    }
}
