// Main.java
package controlador;

import vista.CarnetView;

public class Main {
    public static void main(String[] args) {
        CarnetView view = new CarnetView();
        CarnetController controller = new CarnetController(view);
        view.mostrarVentana();
        controller.iniciar();
    }
}   
