package modelo;

public class Carnet {
    private String codigo;               // Código del carné
    private String universidad;          // Nombre de la universidad
    private String tipoGestion;          // Tipo de gestión (pública o privada)
    private String departamentoFilial;   // Departamento filial asociado
    private String nombreFilial;         // Nombre de la filial
    private String codigoClasePrograma;  // Código de la clase del programa de estudio
    private String nombreClasePrograma;  // Nombre de la clase del programa de estudio
    private String nombrePrograma;       // Nombre del programa de estudio
    private String anioPeriodo;          // Año o período del carné
    private int cantCarnes;              // Cantidad de carnés

    // Constructor de la clase Carnet   
    public Carnet(String codigo, String universidad, String tipoGestion, String departamentoFilial, String nombreFilial,
                  String codigoClasePrograma, String nombreClasePrograma, String nombrePrograma, String anioPeriodo, int cantCarnes) {
        this.codigo = codigo;
        this.universidad = universidad;
        this.tipoGestion = tipoGestion;
        this.departamentoFilial = departamentoFilial;
        this.nombreFilial = nombreFilial;
        this.codigoClasePrograma = codigoClasePrograma;
        this.nombreClasePrograma = nombreClasePrograma;
        this.nombrePrograma = nombrePrograma;
        this.anioPeriodo = anioPeriodo;
        this.cantCarnes = cantCarnes;
    }

    // Método getter para obtener el código del carné
    public String getCodigo() {
        return codigo;
    }

    // Método setter para establecer el código del carné
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    // Método getter para obtener el nombre de la universidad
    public String getUniversidad() {
        return universidad;
    }

    // Método setter para establecer el nombre de la universidad
    public void setUniversidad(String universidad) {
        this.universidad = universidad;
    }

    // Método getter para obtener el tipo de gestión (pública o privada)
    public String getTipoGestion() {
        return tipoGestion;
    }

    // Método setter para establecer el tipo de gestión
    public void setTipoGestion(String tipoGestion) {
        this.tipoGestion = tipoGestion;
    }

    // Método getter para obtener el departamento filial asociado
    public String getDepartamentoFilial() {
        return departamentoFilial;
    }

    // Método setter para establecer el departamento filial
    public void setDepartamentoFilial(String departamentoFilial) {
        this.departamentoFilial = departamentoFilial;
    }

    // Método getter para obtener el nombre de la filial
    public String getNombreFilial() {
        return nombreFilial;
    }

    // Método setter para establecer el nombre de la filial
    public void setNombreFilial(String nombreFilial) {
        this.nombreFilial = nombreFilial;
    }

    // Método getter para obtener el código de la clase del programa de estudio
    public String getCodigoClasePrograma() {
        return codigoClasePrograma;
    }

    // Método setter para establecer el código de la clase del programa de estudio
    public void setCodigoClasePrograma(String codigoClasePrograma) {
        this.codigoClasePrograma = codigoClasePrograma;
    }

    // Método getter para obtener el nombre de la clase del programa de estudio
    public String getNombreClasePrograma() {
        return nombreClasePrograma;
    }

    // Método setter para establecer el nombre de la clase del programa de estudio
    public void setNombreClasePrograma(String nombreClasePrograma) {
        this.nombreClasePrograma = nombreClasePrograma;
    }

    // Método getter para obtener el nombre del programa de estudio
    public String getNombrePrograma() {
        return nombrePrograma;
    }

    // Método setter para establecer el nombre del programa de estudio
    public void setNombrePrograma(String nombrePrograma) {
        this.nombrePrograma = nombrePrograma;
    }

    // Método getter para obtener el año o período del carné
    public String getAnioPeriodo() {
        return anioPeriodo;
    }

    // Método setter para establecer el año o período del carné
    public void setAnioPeriodo(String anioPeriodo) {
        this.anioPeriodo = anioPeriodo;
    }

    // Método getter para obtener la cantidad de carnés
    public int getCantCarnes() {
        return cantCarnes;
    }

    // Método setter para establecer la cantidad de carnés
    public void setCantCarnes(int cantCarnes) {
        this.cantCarnes = cantCarnes;
    }

    // Método toString para obtener una representación en cadena del objeto Carnet
    @Override
    public String toString() {
        return "Carnet{" +
                "codigo='" + codigo + '\'' +
                ", universidad='" + universidad + '\'' +
                ", tipoGestion='" + tipoGestion + '\'' +
                ", departamentoFilial='" + departamentoFilial + '\'' +
                ", nombreFilial='" + nombreFilial + '\'' +
                ", codigoClasePrograma='" + codigoClasePrograma + '\'' +
                ", nombreClasePrograma='" + nombreClasePrograma + '\'' +
                ", nombrePrograma='" + nombrePrograma + '\'' +
                ", anioPeriodo='" + anioPeriodo + '\'' +
                ", cantCarnes=" + cantCarnes +
                '}';
    }
}

