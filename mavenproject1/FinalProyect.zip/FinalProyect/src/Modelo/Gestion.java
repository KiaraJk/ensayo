package modelo;

public enum Gestion {
    PUBLICO, PRIVADO
}

