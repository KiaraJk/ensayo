package modelo;

public class Universidad {
    private String codigo; // Código de la universidad
    private String nombre; // Nombre de la universidad

    // Constructor de la clase Universidad
    public Universidad(String codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }

    // Getter para obtener el código de la universidad
    public String getCodigo() {
        return codigo;
    }

    // Getter para obtener el nombre de la universidad
    public String getNombre() {
        return nombre;
    }

    // Método toString() para representar la universidad como cadena de texto
    @Override
    public String toString() {
        return "Universidad{" +
                "codigo='" + codigo + '\'' +
                ", nombre='" + nombre + '\'' +
                '}';
    }
}

