package modelo;

public class ProgramaEstudio {
    private String codigo; // Código del programa de estudio
    private String nombre; // Nombre del programa de estudio

    // Constructor de la clase ProgramaEstudio
    public ProgramaEstudio(String codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }

    // Getter para obtener el código del programa de estudio
    public String getCodigo() {
        return codigo;
    }

    // Getter para obtener el nombre del programa de estudio
    public String getNombre() {
        return nombre;
    }

    // Método toString() para representar el programa de estudio como cadena de texto
    @Override
    public String toString() {
        return "ProgramaEstudio{" +
                "codigo='" + codigo + '\'' +
                ", nombre='" + nombre + '\'' +
                '}';
    }
}
