package modelo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class CarnetModel {
    private String filePath;
    private String[] lines;  // Usar un arreglo para almacenar las líneas del archivo

    public CarnetModel(String filePath) {
        this.filePath = filePath;
        this.lines = new String[0];
    }

    public void cargarDatosDesdeArchivo() throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            StringBuilder content = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
            this.lines = content.toString().split("\n");
            System.out.println("Datos cargados correctamente desde el archivo: " + filePath);
        } catch (IOException e) {
            System.err.println("Error al cargar datos desde el archivo: " + e.getMessage());
            throw e;
        }
    }

    public String[] obtenerUniversidades() {
        String[] universidades = new String[lines.length];
        int index = 0;
        for (String line : lines) {
            String[] partes = line.split(",");
            if (partes.length > 0) {
                universidades[index++] = partes[0].trim();
            }
        }
        return universidades;
    }

    public Map<String, Integer> obtenerDistribucionCarnesPorUniversidad(String universidad) {
        Map<String, Integer> distribucion = new HashMap<>();
        for (String line : lines) {
            String[] partes = line.split(",");
            if (partes.length > 1 && partes[0].trim().equalsIgnoreCase(universidad)) {
                String departamento = partes[1].trim();
                distribucion.put(departamento, distribucion.getOrDefault(departamento, 0) + 1);
            }
        }
        return distribucion;
    }

    public Map<String, Integer> obtenerReporteDepartamentoFilial(String departamento) {
        Map<String, Integer> reporte = new HashMap<>();
        for (String line : lines) {
            String[] partes = line.split(",");
            if (partes.length > 1 && partes[1].trim().equalsIgnoreCase(departamento)) {
                String filial = partes[2].trim();
                reporte.put(filial, reporte.getOrDefault(filial, 0) + 1);
            }
        }
        return reporte;
    }

    public Map<String, Integer> obtenerReporteProgramasEstudio(String programaEstudio) {
        Map<String, Integer> reporte = new HashMap<>();
        for (String line : lines) {
            String[] partes = line.split(",");
            if (partes.length > 2 && partes[2].trim().equalsIgnoreCase(programaEstudio)) {
                String departamento = partes[1].trim();
                reporte.put(departamento, reporte.getOrDefault(departamento, 0) + 1);
            }
        }
        return reporte;
    }

    public Map<String, Integer> obtenerReporteTipoGestion(String tipoGestion) {
        Map<String, Integer> reporte = new HashMap<>();
        for (String line : lines) {
            String[] partes = line.split(",");
            if (partes.length > 3 && partes[3].trim().equalsIgnoreCase(tipoGestion)) {
                String programaEstudio = partes[2].trim();
                reporte.put(programaEstudio, reporte.getOrDefault(programaEstudio, 0) + 1);
            }
        }
        return reporte;
    }
}
