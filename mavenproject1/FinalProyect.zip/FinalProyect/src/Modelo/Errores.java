package modelo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Errores {
    private String mensajeError;  // Mensaje del error
    private String tipoError;     // Tipo de error
    private String fechaError;    // Fecha del error
    private String horaError;     // Hora del error
    private String origen;        // Origen del error (usuario/sistema)

    // Constructor de la clase Errores
    public Errores(String mensajeError, String tipoError, String origen) {
        this.mensajeError = mensajeError;
        this.tipoError = tipoError;
        this.fechaError = obtenerFechaActual();
        this.horaError = obtenerHoraActual();
        this.origen = origen;
    }

    // Métodos getter y setter para los atributos
    public String getMensajeError() {
        return mensajeError;
    }

    public void setMensajeError(String mensajeError) {
        this.mensajeError = mensajeError;
    }

    public String getTipoError() {
        return tipoError;
    }

    public void setTipoError(String tipoError) {
        this.tipoError = tipoError;
    }

    public String getFechaError() {
        return fechaError;
    }

    public void setFechaError(String fechaError) {
        this.fechaError = fechaError;
    }

    public String getHoraError() {
        return horaError;
    }

    public void setHoraError(String horaError) {
        this.horaError = horaError;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    // Método para obtener la fecha actual en formato "dd/MM/yyyy"
    private String obtenerFechaActual() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return LocalDateTime.now().format(formatter);
    }

    // Método para obtener la hora actual en formato "HH:mm:ss"
    private String obtenerHoraActual() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        return LocalDateTime.now().format(formatter);
    }

    // Método toString para obtener una representación en cadena del objeto Errores
    @Override
    public String toString() {
        return String.format("Errores\n \nmensajeError='%s'\n \ntipoError='%s'\n \nfechaError='%s'\n \nhoraError='%s'\n \norigen='%s'\n",
                
                mensajeError, tipoError, fechaError, horaError, origen);
    }
}
