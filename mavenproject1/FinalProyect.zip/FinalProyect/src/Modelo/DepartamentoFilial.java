package modelo;

public class DepartamentoFilial {
    private String nombre;        // Atributo para almacenar el nombre de la filial o departamento
    private String departamento;  // Atributo para almacenar el nombre del departamento asociado

    // Constructor para inicializar la instancia con nombre y departamento
    public DepartamentoFilial(String nombre, String departamento) {
        this.nombre = nombre;
        this.departamento = departamento;
    }

    // Método para obtener el nombre de la filial
    public String getNombre() {
        return nombre;
    }

    // Método para obtener el nombre del departamento asociado
    public String getDepartamento() {
        return departamento;
    }

    // Método toString para representar el objeto como una cadena de texto
    @Override
    public String toString() {
        return "DepartamentoFilial{" +
                "nombre='" + nombre + '\'' +
                ", departamento='" + departamento + '\'' +
                '}';
    }
}
